<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>
	<script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
	<script async custom-element="amp-image-lightbox" src="https://cdn.ampproject.org/v0/amp-image-lightbox-0.1.js"></script>
	<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom><?php readfile( getcwd()."/styles/style.css"); ?></style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

	
<body class="light-scheme">	
	<header>
		<a href="index.php" class="header-logo header-logo-left"></a>
		<a href="contact.php" class="header-icon-2"><i class="fa fa-envelope-o"></i></a>
	</header>
	<div class="header-clear"></div>
	
	<nav>
		<input type="checkbox" id="toggle-menu">
		<label class="toggle-menu-icon" for="toggle-menu"><em class="l1"></em><em class="l2"></em><em class="l3"></em></label>

		<div id="menu-modal" class="menu menu-modal">
			<div class="menu-scroll">
				<a class="menu-item empty-item" href="#"><span><!-- Menu Fix - Must Stay Empty--></span></a>	
				<a class="menu-item" href="index.php"><i class="fa fa-star"></i><em></em><span>Welcome</span><i class="fa fa-circle"></i></a>	
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-1">
					<label class="menu-item" for="toggle-1"><i class="fa fa-cog"></i><span>Home</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="index-classic.php"><i class="fa fa-angle-right"></i>Classic Home<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="index-splash.php"><i class="fa fa-angle-right"></i>Splash Screen<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="index-landing.php"><i class="fa fa-angle-right"></i>Landing Page<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="index-news.php"><i class="fa fa-angle-right"></i>News Page<i class="fa fa-circle"></i></a>
					</div>	
				</div>		
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-2" checked>
					<label class="menu-item" for="toggle-2"><i class="fa fa-navicon"></i><span>Menus</span></label>
					<div class="submenu-wrapper">
						<a class="active-item menu-item" href="menu-sidebar.php"><i class="fa fa-angle-right"></i><em></em><strong>Sidebar Menu</strong><i class="fa fa-circle"></i></a>
						<a class="menu-item" href="menu-overlay.php"><i class="fa fa-angle-right"></i>Overlay Menu<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="menu-header.php"><i class="fa fa-angle-right"></i>Header Menu<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="menu-landing.php"><i class="fa fa-angle-right"></i>Thumbnail Menu<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-3">
					<label class="menu-item" for="toggle-3"><i class="fa fa-heart"></i><span>Covers</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="cover-1.php"><i class="fa fa-angle-right"></i>Cover Style 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-2.php"><i class="fa fa-angle-right"></i>Cover Style 2<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-3.php"><i class="fa fa-angle-right"></i>Cover Style 3<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-4.php"><i class="fa fa-angle-right"></i>Cover Style 4<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-5.php"><i class="fa fa-angle-right"></i>Cover Style 5<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="7" class="toggle-submenu" id="toggle-4a">
					<label class="menu-item" for="toggle-4a"><i class="fa fa-power-off"></i><span>Features</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="features-type.php"><i class="fa fa-angle-right"></i>Type<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-columns.php"><i class="fa fa-angle-right"></i>Columns<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-buttons.php"><i class="fa fa-angle-right"></i>Buttons<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-inputs.php"><i class="fa fa-angle-right"></i>Inputs<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-quotes.php"><i class="fa fa-angle-right"></i>Quotes<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-dividers.php"><i class="fa fa-angle-right"></i>Dividers<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-headings.php"><i class="fa fa-angle-right"></i>Headings<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="6" class="toggle-submenu" id="toggle-4">
					<label class="menu-item" for="toggle-4"><i class="fa fa-file-o"></i><span>Pages</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="page-404.php"><i class="fa fa-angle-right"></i>404 Page<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-soon.php"><i class="fa fa-angle-right"></i>Soon<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-profile-1.php"><i class="fa fa-angle-right"></i>Profile 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-profile-2.php"><i class="fa fa-angle-right"></i>Profile 2<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-timeline-1.php"><i class="fa fa-angle-right"></i>Timeline 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-timeline-2.php"><i class="fa fa-angle-right"></i>Timeline 2<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="3" class="toggle-submenu" id="toggle-5">
					<label class="menu-item" for="toggle-5"><i class="fa fa-camera"></i><span>Gallery</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="gallery-round.php"><i class="fa fa-angle-right"></i>Round<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="gallery-square.php"><i class="fa fa-angle-right"></i>Square<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="gallery-wide.php"><i class="fa fa-angle-right"></i>Wide<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="3" class="toggle-submenu" id="toggle-6">
					<label class="menu-item" for="toggle-6"><i class="fa fa-image"></i><span>Portfolios</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="portfolio-1.php"><i class="fa fa-angle-right"></i>One Item<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="portfolio-2.php"><i class="fa fa-angle-right"></i>Two Item<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="portfolio-item.php"><i class="fa fa-angle-right"></i>Selected Item<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-7">
					<label class="menu-item" for="toggle-7"><i class="fa fa-newspaper-o"></i><span>News</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="news-list-1.php"><i class="fa fa-angle-right"></i>News List<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-list-2.php"><i class="fa fa-angle-right"></i>News List 2<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-cards.php"><i class="fa fa-angle-right"></i>News Cards<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-post-1.php"><i class="fa fa-angle-right"></i>News Post 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-post-2.php"><i class="fa fa-angle-right"></i>News Post 2<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<a class="menu-item" href="contact.php"><i class="fa fa-envelope-o"></i><span>Contact</span><i class="fa fa-circle"></i></a>	
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-9">
					<label class="menu-item" for="toggle-9"><i class="fa fa-bolt"></i><span>AMP Media</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="amp-daily.php"><i class="fa fa-angle-right"></i>AMP Daily Motion<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-jwp.php"><i class="fa fa-angle-right"></i>AMP JWPlayer<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-soundcloud.php"><i class="fa fa-angle-right"></i>AMP SoundCloud<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-vimeo.php"><i class="fa fa-angle-right"></i>AMP Vimeo<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-youtube.php"><i class="fa fa-angle-right"></i>AMP Youtube<i class="fa fa-circle"></i></a>
					</div>	
				</div>		
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-10">
					<label class="menu-item" for="toggle-10"><i class="fa fa-bolt"></i><span>AMP Social</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="amp-facebook.php"><i class="fa fa-angle-right"></i>AMP Facebook<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-twitter.php"><i class="fa fa-angle-right"></i>AMP Twitter<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-instagram.php"><i class="fa fa-angle-right"></i>AMP Instagram<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-pinterest.php"><i class="fa fa-angle-right"></i>AMP Pinterest<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-social-share.php"><i class="fa fa-angle-right"></i>AMP Social Share<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="7" class="toggle-submenu" id="toggle-11">
					<label class="menu-item" for="toggle-11"><i class="fa fa-bolt"></i><span>AMP Features</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="amp-accordion.php"><i class="fa fa-angle-right"></i>AMP Accordion<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-carousel.php"><i class="fa fa-angle-right"></i>AMP Carousel<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-fonts.php"><i class="fa fa-angle-right"></i>AMP Fonts<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-maps.php"><i class="fa fa-angle-right"></i>AMP Maps<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-lightbox.php"><i class="fa fa-angle-right"></i>AMP LightBox<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-list.php"><i class="fa fa-angle-right"></i>AMP List<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-notifications.php"><i class="fa fa-angle-right"></i>AMP User Notifications<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<label class="menu-item" for="toggle-menu"><i class="fa fa-times"></i><span>Close Menu</span><i class="fa fa-circle"></i></label>
			</div>			
		</div>
	</nav>

	<div class="page-content">
		<div class="page-content-scroll">
			<div class="sliders">
				<amp-carousel class="slider" width="600" height="375" layout="responsive" type="slides" controls autoplay loop delay="3000">
					<div>
						<amp-img class="responsive-img" src="images/pictures/1.jpg" layout="fill"></amp-img>
						<div class="caption">
							<h3>Our first AMP Item</h3>
							<p>Built with awesome features!</p>
						</div>
					</div>
					<div>
						<amp-img class="responsive-img" src="images/pictures/2.jpg" layout="fill"></amp-img>
						<div class="caption">
							<h3 class="center-text">Our first AMP Item</h3>
							<p class="center-text">Built with awesome features!</p>
						</div>
					</div>
					<div>
						<amp-img class="responsive-img" src="images/pictures/3.jpg" layout="fill"></amp-img>
						<div class="caption">
							<h3>Our first AMP Item</h3>
							<p>Built with awesome features!</p>
						</div>
					</div>
				</amp-carousel>
			</div>
			
			<div class="decoration decoration-margins"></div>

			<div class="content">		
				<div class="container">
					<h5 class="center-text uppercase ultrabold">interacting</h5>
					<h4 class="center-text uppercase bold half-bottom">with simplicity</h4>
					<p class="center-text boxed-text">
						Simple interfaces are easy to use and focus on device speed, and your user experience and device interaction.
					</p>
					<div class="social-icons">
						<a href="#" class="color-white facebook-bg center-text"><i class="fa fa-facebook"></i></a>
						<a href="#" class="color-white google-bg center-text"><i class="fa fa-google-plus"></i></a>
						<a href="#" class="color-white twitter-bg center-text"><i class="fa fa-twitter"></i></a>
						<div class="clear"></div>
					</div>
				</div>	
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="heading-block bg-1">
				<h4>Powerful</h4>
				<p>We have some awesome features for you</p>
				<div class="overlay"></div>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="content">
				<div class="icon-heading">
					<h4><i class="fa fa-cog"></i>Works with all mobile devices</h4>
					<p>
						We build our products on the idea that they will be used by users with different devices, for a beautiful experience all around.
					</p>
					<h4><i class="fa fa-user"></i>User friendly, easy to edit</h4>
					<p>
						We know our users need simplicity for them to be able to easily edit and launch their products efficiently without headaches.
					</p>
					<h4><i class="fa fa-star"></i>Envato Elite. Nieche Leader</h4>
					<p>
						We're the lead developer of Mobile and Tablet templates on the Envato marketplace, and Elite Authors. We place quality first!
					</p>
					<h4><i class="fa fa-star"></i>Enviourmentaly Friend.</h4>
					<p>
						Designed to run smooth, fast, and not drain battery from millions of background running processes to take care of your device.
					</p>
				</div>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="content half-bottom">
				<amp-img class="full-bottom" src="images/demo_img.png" width="800" height="518" layout="responsive"></amp-img>
				<div class="left-column">
					<ul class="icon-list">
						<li><i class="fa fa-user"></i>User List</li>
						<li><i class="fa fa-refresh"></i>Activity Feed</li>
						<li><i class="fa fa-calendar-o"></i>Calendar Page</li>
						<li><i class="fa fa-file-o"></i>Coverpage</li>
						<li><i class="fa fa-bold"></i>Typography</li>
						<li><i class="fa fa-flash"></i>jQuery</li>
						<li><i class="fa fa-home"></i>Landing Page</li>
						<li><i class="fa fa-exclamation"></i>404 Page</li>
						<li><i class="fa fa-clock-o"></i>Soon Page</li>
						<li><i class="fa fa-navicon"></i>Timeline Page</li>
						<li><i class="fa fa-file-o"></i>Coverpage</li>
						<li><i class="fa fa-lock"></i>Login Page</li>
					</ul>
				</div>
				<div class="right-column">
					<ul class="icon-list">
						<li><i class="fa fa-power-off"></i> CSS3 Buttons</li>
						<li><i class="fa fa-comment-o"></i>Chat Bubbles</li>
						<li><i class="fa fa-apple"></i>OS Detection</li>
						<li><i class="fa fa-toggle-on"></i>OS Toggles</li>
						<li><i class="fa fa-share-alt"></i>Share Boxes</li>
						<li><i class="fa fa-pie-chart"></i>Charts &amp; Pies</li>
						<li><i class="fa fa-warning"></i>Updates Page</li>
						<li><i class="fa fa-youtube-play"></i>Videos Page</li>
						<li><i class="fa fa-envelope-o"></i>Contact Page</li>
						<li><i class="fa fa-pencil"></i>Blog Template</li>
						<li><i class="fa fa-picture-o"></i>Portfolio Page</li>
						<li><i class="fa fa-camera full-bottom"></i>Gallery Page</li>
					</ul>
				</div>
				<div class="clear"></div>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="heading-block bg-2">
				<h4 class="center-text">Still not convinced?</h4>
				<p class="center-text">Built byt he elite nieche leaders of mobile items, we know how to give you the best of the best with no compromises!</p>
				<a href="#" class="button">Purchase</a>
				<div class="overlay"></div>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="quote-style">
				<h4 class="half-bottom">
					Great all around product, with one of the best documentations I have ever seen. Really thorough and easy to follow!
					Also the support responsiveness is really fantastic. Extremely happy with everything. Thanks again!
				</h4>
				<div class="rating">
					<i class="color-yellow-dark fa fa-star"></i>
					<i class="color-yellow-dark fa fa-star"></i>
					<i class="color-yellow-dark fa fa-star"></i>
					<i class="color-yellow-dark fa fa-star"></i>
					<i class="color-yellow-dark fa fa-star"></i>
				</div>
				<p><a class="center-text" href="#">ThemeForest Buyer</a></p>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="heading-block bg-2">
				<h4>Meet the staff!</h4>
				<p>They're here to help</p>
				<div class="overlay"></div>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="content full-bottom">
				<div class="left-column">
					<amp-img class="half-bottom round-image" src="images/pictures/1t.jpg" width="200" height="200" layout="responsive"></amp-img>
					<h5 class="center-text">John Doe</h5>
					<em class="color-red-dark small-text center-text half-bottom">Front End Designer</em>
					<p class="center-text small-text half-bottom">
						Lorem Ipsum has been the industry's standard dummy text ever since the fifteenhundreds. 
					</p>
					<div class="social-icons-small">
						<a href="#" class="color-white facebook-bg center-text"><i class="fa fa-facebook"></i></a>
						<a href="#" class="color-white twitter-bg center-text"><i class="fa fa-twitter"></i></a>
						<div class="clear"></div>
					</div>
				</div>
				<div class="right-column">
					<amp-img class="half-bottom round-image" src="images/pictures/2t.jpg" width="200" height="200" layout="responsive"></amp-img>
					<h5 class="center-text">John Doe</h5>
					<em class="color-red-dark small-text center-text half-bottom">Front End Designer</em>
					<p class="center-text small-text half-bottom">
						Lorem Ipsum has been the industry's standard dummy text ever since the fifteenhundreds. 
					</p>
					<div class="social-icons-small">
						<a href="#" class="color-white phone-bg center-text"><i class="fa fa-phone"></i></a>
						<a href="#" class="color-white mail-bg center-text"><i class="fa fa-envelope"></i></a>
						<div class="clear"></div>
					</div>
				</div>
				<div class="right-column">

				</div>
				<div class="clear"></div>
			</div>

			<div class="decoration decoration-margins"></div>
			<div class="heading-block bg-2">
				<h4>One more thing!</h4>
				<p>There's always more to our files!</p>
				<div class="overlay"></div>
			</div>
			<div class="decoration decoration-margins"></div>

			<div class="half-column-left">
				<amp-img class="half-left-img" src="images/pictures/9t.jpg" width="100" height="100"></amp-img>
				<h4>Mobile Ready</h4>
				<p>
					Pixel perfect designs are what we care about. Quality above all!
				</p>
			</div>
			<div class="half-column-right">
				<amp-img class="half-right-img" src="images/pictures/8t.jpg" width="100" height="100"></amp-img>
				<h4>Google AMP</h4>
				<p>
					Built and Validated using the latest code provided by Google AMP!
				</p>
			</div>
			<div class="half-column-left">
				<amp-img class="half-left-img" src="images/pictures/3t.jpg" width="100" height="100"></amp-img>
				<h4>Custom Features</h4>
				<p>
					Tones of awesome mobile features designed to integrate in AMP!
				</p>
			</div>
			<div class="half-column-right">
				<amp-img class="half-right-img" src="images/pictures/2t.jpg" width="100" height="100"></amp-img>
				<h4>Easy, just add water!</h4>
				<p>
					Things are made as easy as possible for you to work with!
				</p>
			</div>

			<div class="decoration decoration-margins"></div>
			<div class="heading-block bg-2">
				<h4>More awesome projects!</h4>
				<p>See more of our products!</p>
				<div class="overlay"></div>
			</div>
			<div class="decoration decoration-margins"></div>

			<div class="content">
				<amp-image-lightbox id="lightbox1"layout="nodisplay"></amp-image-lightbox>
				<div class="gallery full-bottom">
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/0t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/1t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/2t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/3t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/4t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/5t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/6t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/7t.jpg" width="300" height="300"></amp-img>
					 <amp-img class="gallery-thumb" on="tap:lightbox1" role="button" tabindex="0" layout="responsive" src="images/pictures/8t.jpg" width="300" height="300"></amp-img>
					<div class="clear"></div>
				</div>
			</div>

			<div class="footer">
				<div class="decoration decoration-margins"></div>
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="decoration decoration-margins"></div>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					<a href="https://plus.google.com/u/2/105775801838187143320" class="google-bg"><i class="fa fa-google-plus"></i></a>
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>

			
		</div>
	</div>

	
</body>
</html>