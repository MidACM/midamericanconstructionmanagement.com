<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom><?php readfile( getcwd()."/styles/style.css"); ?></style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

	
<body class="light-scheme">	
	<header>
		<a href="index.php" class="header-logo header-logo-left"></a>
		<a href="contact.php" class="header-icon-2"><i class="fa fa-envelope-o"></i></a>
	</header>
	<div class="header-clear"></div>
	
	<nav>
		<input type="checkbox" id="toggle-menu">
		<label class="toggle-menu-icon" for="toggle-menu"><em class="l1"></em><em class="l2"></em><em class="l3"></em></label>

		<div id="menu-modal" class="menu menu-modal">
			<div class="menu-scroll">
				<a class="menu-item empty-item" href="#"><span><!-- Menu Fix - Must Stay Empty--></span></a>	
								
				<a class="menu-item" href="index.php"><i class="fa fa-star"></i><span>Welcome</span><i class="fa fa-circle"></i></a>	
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-1">
					<label class="menu-item" for="toggle-1"><i class="fa fa-cog"></i><span>Home</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="index-classic.php"><i class="fa fa-angle-right"></i>Classic Home<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="index-splash.php"><i class="fa fa-angle-right"></i>Splash Screen<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="index-landing.php"><i class="fa fa-angle-right"></i>Landing Page<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="index-news.php"><i class="fa fa-angle-right"></i>News Page<i class="fa fa-circle"></i></a>
					</div>	
				</div>		
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-2">
					<label class="menu-item" for="toggle-2"><i class="fa fa-navicon"></i><span>Menus</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="menu-sidebar.php"><i class="fa fa-angle-right"></i>Sidebar Menu<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="menu-overlay.php"><i class="fa fa-angle-right"></i>Overlay Menu<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="menu-header.php"><i class="fa fa-angle-right"></i>Header Menu<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="menu-landing.php"><i class="fa fa-angle-right"></i>Thumbnail Menu<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-3">
					<label class="menu-item" for="toggle-3"><i class="fa fa-heart"></i><span>Covers</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="cover-1.php"><i class="fa fa-angle-right"></i>Cover Style 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-2.php"><i class="fa fa-angle-right"></i>Cover Style 2<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-3.php"><i class="fa fa-angle-right"></i>Cover Style 3<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-4.php"><i class="fa fa-angle-right"></i>Cover Style 4<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="cover-5.php"><i class="fa fa-angle-right"></i>Cover Style 5<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="7" class="toggle-submenu" id="toggle-4a" checked>
					<label class="menu-item" for="toggle-4a"><i class="fa fa-power-off"></i><span>Features</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="features-type.php"><i class="fa fa-angle-right"></i>Type<i class="fa fa-circle"></i></a>
						<a class="active-item menu-item" href="features-columns.php"><i class="fa fa-angle-right"></i><em></em><strong>Columns</strong><i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-buttons.php"><i class="fa fa-angle-right"></i>Buttons<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-inputs.php"><i class="fa fa-angle-right"></i>Inputs<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-quotes.php"><i class="fa fa-angle-right"></i>Quotes<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-dividers.php"><i class="fa fa-angle-right"></i>Dividers<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="features-headings.php"><i class="fa fa-angle-right"></i>Headings<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="6" class="toggle-submenu" id="toggle-4">
					<label class="menu-item" for="toggle-4"><i class="fa fa-file-o"></i><span>Pages</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="page-404.php"><i class="fa fa-angle-right"></i>404 Page<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-soon.php"><i class="fa fa-angle-right"></i>Soon<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-profile-1.php"><i class="fa fa-angle-right"></i>Profile 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-profile-2.php"><i class="fa fa-angle-right"></i>Profile 2<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-timeline-1.php"><i class="fa fa-angle-right"></i>Timeline 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="page-timeline-2.php"><i class="fa fa-angle-right"></i>Timeline 2<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="3" class="toggle-submenu" id="toggle-5">
					<label class="menu-item" for="toggle-5"><i class="fa fa-camera"></i><span>Gallery</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="gallery-round.php"><i class="fa fa-angle-right"></i>Round<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="gallery-square.php"><i class="fa fa-angle-right"></i>Square<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="gallery-wide.php"><i class="fa fa-angle-right"></i>Wide<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="3" class="toggle-submenu" id="toggle-6">
					<label class="menu-item" for="toggle-6"><i class="fa fa-image"></i><span>Portfolios</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="portfolio-1.php"><i class="fa fa-angle-right"></i>One Item<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="portfolio-2.php"><i class="fa fa-angle-right"></i>Two Item<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="portfolio-item.php"><i class="fa fa-angle-right"></i>Selected Item<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-7">
					<label class="menu-item" for="toggle-7"><i class="fa fa-newspaper-o"></i><span>News</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="news-list-1.php"><i class="fa fa-angle-right"></i>News List<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-list-2.php"><i class="fa fa-angle-right"></i>News List 2<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-cards.php"><i class="fa fa-angle-right"></i>News Cards<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-post-1.php"><i class="fa fa-angle-right"></i>News Post 1<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="news-post-2.php"><i class="fa fa-angle-right"></i>News Post 2<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<a class="menu-item" href="contact.php"><i class="fa fa-envelope-o"></i><span>Contact</span><i class="fa fa-circle"></i></a>	
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-9">
					<label class="menu-item" for="toggle-9"><i class="fa fa-bolt"></i><span>AMP Media</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="amp-daily.php"><i class="fa fa-angle-right"></i>AMP Daily Motion<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-jwp.php"><i class="fa fa-angle-right"></i>AMP JWPlayer<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-soundcloud.php"><i class="fa fa-angle-right"></i>AMP SoundCloud<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-vimeo.php"><i class="fa fa-angle-right"></i>AMP Vimeo<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-youtube.php"><i class="fa fa-angle-right"></i>AMP Youtube<i class="fa fa-circle"></i></a>
					</div>	
				</div>		
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="5" class="toggle-submenu" id="toggle-10">
					<label class="menu-item" for="toggle-10"><i class="fa fa-bolt"></i><span>AMP Social</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="amp-facebook.php"><i class="fa fa-angle-right"></i>AMP Facebook<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-twitter.php"><i class="fa fa-angle-right"></i>AMP Twitter<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-instagram.php"><i class="fa fa-angle-right"></i>AMP Instagram<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-pinterest.php"><i class="fa fa-angle-right"></i>AMP Pinterest<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-social-share.php"><i class="fa fa-angle-right"></i>AMP Social Share<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<div class="submenu-item">
					<input type="checkbox" data-submenu-items="7" class="toggle-submenu" id="toggle-11">
					<label class="menu-item" for="toggle-11"><i class="fa fa-bolt"></i><span>AMP Features</span></label>
					<div class="submenu-wrapper">
						<a class="menu-item" href="amp-accordion.php"><i class="fa fa-angle-right"></i>AMP Accordion<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-carousel.php"><i class="fa fa-angle-right"></i>AMP Carousel<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-fonts.php"><i class="fa fa-angle-right"></i>AMP Fonts<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-maps.php"><i class="fa fa-angle-right"></i>AMP Maps<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-lightbox.php"><i class="fa fa-angle-right"></i>AMP LightBox<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-list.php"><i class="fa fa-angle-right"></i>AMP List<i class="fa fa-circle"></i></a>
						<a class="menu-item" href="amp-notifications.php"><i class="fa fa-angle-right"></i>AMP User Notifications<i class="fa fa-circle"></i></a>
					</div>	
				</div>
				<label class="menu-item" for="toggle-menu"><i class="fa fa-times"></i><span>Close Menu</span><i class="fa fa-circle"></i></label>
			</div>			
		</div>
	</nav>

	<div class="page-content">
		<div class="page-content-scroll">

			<div class="heading-block bg-1">
				<h4>Columns</h4>
				<p>Quality crafted, AMP valid!</p>
				<div class="overlay"></div>
			</div>

			<div class="content">
				<div>
					<h4 class="quarter-bottom">1/1</h4>
					<amp-img class="half-bottom" src="images/pictures/0ww.jpg" layout="responsive" width="300" height="80"></amp-img>
					<p>
						Praesent eget massa tristique, viverra nulla in, euismod lacus. Phasellus vitae urna quis arcu iaculis posuere
					</p>
				</div>
				<div class="left-column">
					<h4 class="quarter-bottom">1/2</h4>
					<amp-img class="half-bottom" src="images/pictures/1ww.jpg" layout="responsive" width="300" height="130"></amp-img>
					<p>
						Praesent eget massa tristique, viverra nulla in, euismod lacus. Phasellus vitae urna quis arcu iaculis posuere
					</p>
				</div>
				<div class="right-column">
					<h4 class="quarter-bottom">2/2</h4>
					<amp-img class="half-bottom" src="images/pictures/2ww.jpg" layout="responsive" width="300" height="130"></amp-img>
					<p>
						Praesent eget massa tristique, viverra nulla in, euismod lacus. Phasellus vitae urna quis arcu iaculis posuere
					</p>
				</div>
				<div class="clear"></div>
			</div>

			<div class="decoration decoration-margins"></div>

			<div class="content">
				<div class="one-third-left">
					<h4 class="quarter-bottom">1/3</h4>
					<amp-img class="half-bottom" src="images/pictures/1ww.jpg" layout="responsive" width="300" height="130"></amp-img>
					<p>Cras egestas mollis semper.</p>
				</div>
				<div class="one-third-center">
					<h4 class="quarter-bottom">2/3</h4>
					<amp-img class="half-bottom" src="images/pictures/1ww.jpg" layout="responsive" width="300" height="130"></amp-img>
					<p>Cras egestas mollis semper.</p>
				</div>
				<div class="one-third-right">
					<h4 class="quarter-bottom">3/3</h4>
					<amp-img class="half-bottom" src="images/pictures/1ww.jpg" layout="responsive" width="300" height="130"></amp-img>
					<p>Cras egestas mollis semper.</p>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="footer">
				<div class="decoration decoration-margins"></div>
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="decoration decoration-margins"></div>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					<a href="https://plus.google.com/u/2/105775801838187143320" class="google-bg"><i class="fa fa-google-plus"></i></a>
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>

			
		</div>
	</div>

	
</body>
</html>